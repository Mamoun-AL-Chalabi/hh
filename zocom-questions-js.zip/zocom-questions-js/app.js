// 1 Vilka datatyper finns det i JS? Svara i form av en array.

// let datatypes = []

let datatypes = ['hello', 187, null, undefined, true, false]

// 2 Är följande if sats true eller false?

// let a = 1;
// let b = '1';
// if(a == b) // true or false


// ITS TRUE


// 3 Vad är den tekniska skillnaden ( förutom var, let ) på dessa två deklarationer?

// let name = 'Greta Thunberg';
// var name = 'Greta Thunberg';

// var = global scope
// let = local scope



// 4. Hur tar man reda på vad en variabel har för datatyp?

// Hur man tar reda på en variabel
// let anything = 'mamoun';

// console.log(typeof(anything))


// 5 Vilken av följande tecken visar ett kodblock?

// [] // A 
// () // B
// {} // C

// Svaret: C


// 6 Vad i följande kod är blocket som exekveras?
//  DIDNT SOLVE THIS YET

// el.on('click', () => {
//     alert('Ariba!');
// })


// 7 Vad kommer stå i console.log()?

// var greeting = 'Good bye world!';

// {
//     let greeting = 'Hello World';
// }

// console.log(greeting);

// svaret är 'Good bye world!';


// 8 Vilken av följande syntax är korrekt sätt att skriva strängar.

// "Hello World" // A
// 'Hello World' // B
// `Hello World` // C

// svaret är: B



// 9 Räkna antal tecken i strängen nedan.

// let sentence = "If you're having code problems I feel bad for you son. I got 99 problems, but a glitch ain't one."


// svaret är:  console.log(sentence.length)       97



// 10 Gör en template string där N ersätts med variabeln name.

// let name = 'Arber';

// svaret är:    console.log(`Hej ${name} din gamle knasboll!`);






// 11 Gör en array med 5 frukter i.

// 12 Lägg till en frukt i början och en frukt i slutet på arrayen.

// 13 I ovanstående fruktarray, plocka bort första och sista frukten.


// let fruits = ['peach', 'apple', 'ananas', 'pear', 'banana']

// svaret är nedan

// fruits.unshift('kiwi')
// fruits.push('strawberry')
// fruits.pop()
// fruits.shift()
// console.log(fruits)



// 14 I följande array, sätt in två nya frukter på index 2.
// let fruits = ['apple', 'orange', 'pear', 'kiwi']

// svaret är nedan

// fruits.splice(2, 0, 'kiwi, strawberry')

// console.log(fruits)



// 15 Klona följande array och ändra första frukten till pineapple.

// let fruits = ['apple', 'orange', 'pear', 'kiwi']

// svaret är nedan;

// fruits.splice(0, 1, 'pineapple')

// console.log(fruits)



// 16 Sortera följande array i fallande ordning.

// let num = [1,5,78,7,122,3,4,65,40,2,8]

// svaret är nedan:

// num.sort((a, b) => { return a - b });
 
// console.log(num);


// 17 Lägg ihop följande arrayer.

// let a = [1,2,3];
// let b = [4,5,6];

// svaret är nedan:

// let m = a.concat(b)

// console.log(m)



// 18 Mixa följande arrayer där varannan är från array a och varanan från array b.

// let a = ['My', 'has', 'many', 'open'];
// let b = ['brain', 'to', 'tabs', '!'];

// kollade google, men jag förstår riktigt inte.

// let result = a.map(
//     (element, index) => [element, b[index]]
//   ).flat();
  
//   console.log(result);


// 19 Merga in array a i array b på index 2.

// let a = [1,2,7,8,9,10];
// let b = [3,4,5,6];

// svaret är nedan

// a.splice(2, 0, ...b)

// console.log(a)


// 20 Gör alla namn i array names till versaler.
// let names = ['sixten', 'Eva', 'Ali', 'Kim', 'Greger', 'Alicia'];

// svaret är nedan

// const uppercased = names.map(name => name.toUpperCase());

// console.log(uppercased)



// 21 Filtrera fram samtliga personer som är 30 år eller äldre.

// let names = [
//     { name: 'sixten', age: 32 },
//     { name: 'Eva',    age: 19 }, 
//     { name: 'Ali',    age: 67 },
//     { name: 'Kim',    age: 13 },
//     { name: 'Greger', age: 30 },
//     { name: 'Alicia', age: 82 }
//     ];

// svaret nedan:       (förstår inte riktigt)

//     let bigger30 = names.filter(ag => {
//         return ag.age > 30;
//     })
//         console.log(bigger30)


// 22 Skriv koden för att undersöka om arrayen names innehåller namnet Ewa. Ditt svar ska vara true eller false.

// let names = ['sixten', 'Eva', 'Ali', 'Kim', 'Greger', 'Alicia'];

// for (let i = 'Ewa'; i = names.length; i++) {

//     console.log('andrew')
// } /////////////// vet ej


// 23 Skapa en for-loop som itererar 1000 varv. För varje iteration ska du console.log() vilket varv du är på.

// svaret är nedan

// for (let i = 0; i < 1000; i++) {
//     console.log(i)
// }



// 24 Skapa en for-loop som räknar ner från 100 till 0. För varje varv ska du console.log() vilket varv du är på.

// for (let i = 100; i > 0; i--) {
//     console.log(i)
// }


// 25 Loopa ut följande array med console.log().

// let fruits = ['apple', 'orange', 'pear', 'kiwi', 'pineapple'];

// svaret nedan

// for (let i = 0; i < fruits.length; i++) {
//     console.log(fruits[i])
// }


// 26 Loopa ut föregående array med console.log(). Sätt vilket index varje frukt har framför. Ex. 0. apple, 1. orange osv.


// let fruits = ['apple', 'orange', 'pear', 'kiwi', 'pineapple'];

// lite svår

// fruits.forEach(function (item, index) {
//     console.log(index, item);
//   });



// 27 Generera en kortlek med 52 kort där varje kort innehåller en färg ( suite ) och ett värde mellan 2 och 14 ( ess ). Ex.

// kan inte

// [..., 'hjärter 8', 'hjärter 9', ...]


// 28 Skapa en ett objekt som heter book och som har egenskaperna title, author och genres. De två första egenskaperna ska vara strängar och den sista en array.

//  svaret är nedan

// let book = {
//     title: 'nature',
//     author: 'alex',
//     genre: ['horror']
// }

// console.log(book)









// 29 console.log() endast egenskapen city i följande objekt.

// svaret är nedan

// let person = {
//     name: 'Sixten Faceplant',
//     email: 'sixten.faceplant@zocom.se',
//     role: 'ninjah',
//     adress: {
//         street: 'Karatevägen 3',
//         zip: '41477',
//         city: 'Kablam City'
//     }
// }

// console.log(person.adress.city)



// 30 Klona ett objekt.

// svaret är nedan

// let hello = {
//     word: 'everyone',
// }

// let clone = {
//     ...hello
// }

// console.log(clone)



// 31 Skapa objektet dog med egenskaperna name, breed och metoden bark som ska returnera "Woff, jag heter N!" där N ska ersättas med egenskapen name i samma objekt.

// vet inte hur man gör

// let dog = {
//     name: 'abby',
//     breed: 'chihuahua',
//     bark: 'Woff, jag heter',
//     hello: function () {
//         return this.bark + " " + this.name;
//     }

// }

// console.log(dog)


// 32 Loopa ut följande objekt där key och value ska console.log(). Ex. "name - Sixten".

// let person = { 
//     name: 'sixten',
//     email: 'sixten@zocom.se', 
//     role: 'ninjah',
//     age: 32 
// }

// for (const [key, value] of Object.entries(person)) {
//     console.log(`${key}: ${value}`);
// }